AJMAL FREE KEYWORD FINDER — PUBLISH CHECKLIST

1) Upload index.html, robots.txt, sitemap.xml and 404.html to your hosting.
2) Before publishing, replace YOUR-DOMAIN.example in robots.txt, sitemap.xml and index.html canonical URL with your REAL website domain.
3) GitHub Pages can host these files for free. Create a PUBLIC repository, upload the files, then Settings > Pages > Deploy from branch > main > /(root).
4) Open the generated github.io address and test LIVE SEARCH in Chrome with internet access.
5) For Google Search Console: open Search Console, add your site property, verify ownership (DNS verification is preferred for a domain property), then submit:
   https://YOUR-DOMAIN.example/sitemap.xml
6) URL Inspection: enter the homepage URL and request indexing. Google decides when/if a page is crawled/indexed; requesting indexing does not guarantee ranking or immediate inclusion.
7) After getting the real domain, update the canonical, robots and sitemap URLs to that domain.

IMPORTANT:
- Do not publish fake monthly search-volume numbers. The tool labels autocomplete-derived signals separately from verified search volume.
- TikTok/Instagram/Facebook do not expose one universal free public native monthly-volume API. Their results are keyword ideas, not claimed native platform volume.
