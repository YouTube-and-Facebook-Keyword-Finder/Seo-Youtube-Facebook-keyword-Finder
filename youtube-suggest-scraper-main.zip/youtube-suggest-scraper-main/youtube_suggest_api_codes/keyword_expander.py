"""
Build a YouTube keyword list from one seed - Chocodata YouTube Suggest Scraper API

Expands a seed keyword breadth-first through YouTube's own autocomplete graph and
writes the deduplicated result to CSV. One API call per node visited. Pin the
locale with --language so every level is harvested in the same language.

    pip install requests
    export CHOCODATA_API_KEY="your_key"      # free: 1,000 requests, one-time
    python youtube_suggest_api_codes/keyword_expander.py "python" --depth 2 --language en

Docs: https://chocodata.com/docs
"""
import argparse
import csv
import os
import sys
import time
import urllib.parse

import requests

API = "https://api.chocodata.com/api/v1/youtube/suggest"
KEY = os.environ.get("CHOCODATA_API_KEY")

if not KEY:
    sys.exit("Set CHOCODATA_API_KEY first. Free key (1,000 requests, one-time): https://chocodata.com")


def _check(r) -> None:
    """Map the API's documented errors onto actionable messages instead of a traceback."""
    if r.status_code == 400:
        sys.exit(f"400 invalid_params: {r.text[:200]}")
    if r.status_code == 401:
        sys.exit("401 INVALID_API_KEY: key missing or not recognised. Get one: https://chocodata.com")
    if r.status_code == 402:
        sys.exit("402 INSUFFICIENT_CREDITS: balance exhausted. Top up or upgrade: https://chocodata.com/pricing")
    if r.status_code == 429:
        sys.exit("429 RATE_LIMITED: over your plan's concurrency or the 120/60s rate limit. Back off and retry.")
    r.raise_for_status()


def search_url(term: str) -> str:
    """The standard YouTube results URL for a term, built locally. The API returns
    bare strings; this is a convenience so each row can feed a downstream scraper."""
    return "https://www.youtube.com/results?search_query=" + urllib.parse.quote(term)


def fetch(query: str, language: str | None, country: str | None) -> list:
    """One node. Returns the suggestion strings, with the seed echo dropped.

    Google occasionally refuses the request with a 502, which is retryable and
    uncharged: give it one more go after an 8s gap before skipping the term."""
    params = {"api_key": KEY, "query": query}
    if language:
        params["language"] = language
    if country:
        params["country"] = country
    for attempt in (1, 2):
        r = requests.get(API, params=params, timeout=90)
        if r.status_code == 502 and attempt == 1:
            time.sleep(8)
            continue
        if r.status_code == 502:
            print(f"  ! {query}: suggest endpoint refused every attempt, skipping (not charged)")
            return []
        _check(r)
        return [s for s in r.json().get("related_searches", []) if s and s != query]
    return []


def expand(seed: str, depth: int, language: str | None, country: str | None, pause: float) -> dict:
    """Breadth-first walk. Returns {term: {parent, depth}}."""
    found = {seed: {"parent": None, "depth": 0}}
    frontier, calls = [seed], 0

    for level in range(depth):
        nxt = []
        for term in frontier:
            rows = fetch(term, language, country)
            calls += 1
            new = 0
            for q in rows:
                if q in found:
                    continue
                found[q] = {"parent": term, "depth": level + 1}
                nxt.append(q)
                new += 1
            print(f"  depth {level + 1}  {term!r} -> {len(rows)} suggestions, {new} new")
            time.sleep(pause)
        frontier = nxt
        if not frontier:
            break

    found["_calls"] = calls
    return found


def main() -> None:
    ap = argparse.ArgumentParser(description="Expand a YouTube seed keyword through autocomplete suggestions.")
    ap.add_argument("seed", nargs="?", default="python")
    ap.add_argument("--depth", type=int, default=2, help="levels to expand (default 2)")
    ap.add_argument("--language", default="en", help="hl locale, e.g. en, de, es (default en)")
    ap.add_argument("--country", default=None, help="gl country, e.g. us, de (default: unset)")
    ap.add_argument("--pause", type=float, default=0.6, help="seconds between calls (rate limit is 120/60s)")
    ap.add_argument("--out", default="youtube_keywords.csv")
    args = ap.parse_args()

    print(f"Expanding {args.seed!r} to depth {args.depth} (language={args.language})")
    found = expand(args.seed, args.depth, args.language, args.country, args.pause)
    calls = found.pop("_calls")

    rows = sorted(found.items(), key=lambda kv: (kv[1]["depth"], kv[0]))
    with open(args.out, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["keyword", "parent", "depth", "youtube_search_url"])
        for term, meta in rows:
            w.writerow([term, meta["parent"] or "", meta["depth"], search_url(term)])

    by_depth = {}
    for _, meta in rows:
        by_depth[meta["depth"]] = by_depth.get(meta["depth"], 0) + 1
    spread = ", ".join(f"depth {d}: {n}" for d, n in sorted(by_depth.items()))
    print()
    print(f"{len(rows)} unique keywords from {calls} API call(s) ({spread}) -> {args.out}")


if __name__ == "__main__":
    main()
