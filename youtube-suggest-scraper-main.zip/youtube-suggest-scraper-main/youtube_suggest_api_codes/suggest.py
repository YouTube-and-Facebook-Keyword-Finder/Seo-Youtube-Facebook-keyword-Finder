"""
YouTube Suggest - Chocodata YouTube Suggest Scraper API

Runnable example. It calls the LIVE API and prints the real JSON response.

    pip install requests
    export CHOCODATA_API_KEY="your_key"      # free: 1,000 requests, one-time
    python youtube_suggest_api_codes/suggest.py "python"

Docs: https://chocodata.com/docs
"""
import json
import os
import sys
import time

import requests

API = "https://api.chocodata.com/api/v1/youtube/suggest"
KEY = os.environ.get("CHOCODATA_API_KEY")

if not KEY:
    sys.exit("Set CHOCODATA_API_KEY first. Free key (1,000 requests, one-time): https://chocodata.com")


def _check(r) -> None:
    """Map the API's documented errors onto actionable messages instead of a traceback."""
    if r.status_code == 400:
        sys.exit(f"400 invalid_params: {r.text[:200]}")
    if r.status_code == 401:
        sys.exit("401 INVALID_API_KEY: key missing or not recognised. Get one: https://chocodata.com")
    if r.status_code == 402:
        sys.exit("402 INSUFFICIENT_CREDITS: balance exhausted. Top up or upgrade: https://chocodata.com/pricing")
    if r.status_code == 429:
        sys.exit("429 RATE_LIMITED: over your plan's concurrency or the 120/60s rate limit. Back off and retry.")
    if r.status_code == 502:
        sys.exit("502 target_unreachable: the suggest endpoint returned nothing parseable. Retryable, and you were not charged.")
    r.raise_for_status()


def suggest(query: str, language: str | None = None, country: str | None = None) -> dict:
    """YouTube's own autocomplete suggestions for a seed keyword.

    `language` (hl) and `country` (gl) pin the locale. Leave them unset and the
    suggestions follow the request location, which is not stable between calls,
    so pass `language` and `country` when you want a deterministic list.
    """
    params = {"api_key": KEY, "query": query}
    if language:
        params["language"] = language
    if country:
        params["country"] = country
    for attempt in (1, 2):
        r = requests.get(API, params=params, timeout=90)
        if r.status_code == 502 and attempt == 1:
            time.sleep(8)
            continue
        break
    _check(r)
    return r.json()


if __name__ == "__main__":
    seed = sys.argv[1] if len(sys.argv) > 1 else "python"
    lang = sys.argv[2] if len(sys.argv) > 2 else "en"
    country = sys.argv[3] if len(sys.argv) > 3 else "us"
    data = suggest(seed, language=lang, country=country)
    print(json.dumps(data, indent=2, ensure_ascii=False))
    print()
    terms = data["related_searches"]
    print(f"{data['related_count']} suggestions for '{data['query']}' "
          f"(language={lang}, country={country}): {', '.join(terms)}")
