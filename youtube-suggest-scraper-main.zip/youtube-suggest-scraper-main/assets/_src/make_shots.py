"""Render developer-journey screenshots from REAL captured session output.

The text rendered here is the verbatim stdout of a real run, committed under
assets/_src/runs/*.txt so this generator works from a fresh clone. sanitize()
strips the API key, any home directory and the username before a pixel is drawn.
"""
import os
import re

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(__file__)
OUT = os.path.join(HERE, "..")
QA = os.path.join(HERE, "runs")
F = "C:/Windows/Fonts/"

MONO = ImageFont.truetype(F + "consola.ttf", 15)
MONOB = ImageFont.truetype(F + "consolab.ttf", 15)
CJK = ImageFont.truetype(F + "YuGothM.ttc", 15)  # Latin + Japanese
UI = ImageFont.truetype(F + "segoeui.ttf", 14)

BG, FG, DIM = (13, 15, 19), (208, 205, 200), (110, 106, 100)
GREEN, BLUE, AMBER, RED, CYAN = ((126, 209, 138), (127, 178, 255), (255, 196, 138),
                                 (232, 118, 118), (120, 205, 210))

SECRET = re.compile(r"asa_live_[A-Za-z0-9_\-]+")


def sanitize(s: str) -> str:
    s = SECRET.sub("$CHOCODATA_API_KEY", s)
    s = re.sub(r"[A-Za-z]:\\Users\\[^\\\s]+", "~", s)
    s = re.sub(r"/c/Users/[^/\s]+", "~", s)
    s = s.replace(os.environ.get("USERNAME", "\0"), "dev")
    return s


def renderable(ch):
    o = ord(ch)
    return o < 0x0250 or 0x3000 <= o <= 0x30FF or 0x4E00 <= o <= 0x9FFF or ch in "’·\t"


def clip(s: str, n: int = 108) -> str:
    """Trim to width; replace glyphs the CJK+Latin font cannot draw (Korean/Thai)."""
    s = s[:n]
    return "".join(ch if renderable(ch) else "?" for ch in s)


def read_out(name):
    p = os.path.join(QA, name)
    if not os.path.exists(p):
        raise SystemExit(f"missing capture: {p}\n  Re-record it by running the matching script "
                         f"and saving its stdout to assets/_src/runs/{name}")
    return sanitize(open(p, encoding="utf-8", errors="replace").read())


def body_lines(src):
    lines = [l for l in read_out(src).strip().splitlines() if l.strip()]
    if not lines:
        raise SystemExit(f"capture {src} is empty; re-record it before rendering")
    return lines


def terminal(lines, path, width=1180, title="youtube-suggest-scraper"):
    pad, lh = 18, 23
    h = 46 + pad * 2 + lh * len(lines)
    img = Image.new("RGB", (width, h), BG)
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, width, 38], fill=(24, 26, 31))
    for i, c in enumerate([(255, 95, 87), (254, 188, 46), (40, 200, 64)]):
        d.ellipse([16 + i * 20, 14, 26 + i * 20, 24], fill=c)
    d.text((width // 2 - 78, 11), title, font=UI, fill=DIM)
    y = 38 + pad
    for text, color, bold, *rest in lines:
        fnt = rest[0] if rest else (MONOB if bold else MONO)
        d.text((pad, y), text, font=fnt, fill=color)
        y += lh
    img.save(os.path.join(OUT, path))
    print("wrote assets/" + path, img.size)


def colorize(l):
    if re.search(r'"\w+":', l):
        return BLUE
    if re.search(r':\s+\d', l):
        return AMBER
    return FG


def shot_suggest():
    body = body_lines("api_suggest.txt")
    lines = [('$ export CHOCODATA_API_KEY="your_key"', GREEN, True),
             ('$ python youtube_suggest_api_codes/suggest.py "python"', GREEN, True), ("", FG, False)]
    for l in body[:14]:
        lines.append((clip(l), colorize(l), False, CJK))
    lines += [("  ...", DIM, False), ("", FG, False), (clip(body[-1]), CYAN, True, CJK)]
    terminal(lines, "run-suggest.png")


def shot_free():
    """The free scraper actually running. It works, and the shot says so."""
    body = body_lines("free_works.txt")
    lines = [('$ python free_scraper/youtube_suggest_free_scraper.py "python" en', GREEN, True),
             ("", FG, False)]
    for l in body:
        lines.append((clip(l), FG, False, CJK))
    lines += [("", FG, False),
              ("# no key, no browser: a plain GET to Google's suggest endpoint.", DIM, False)]
    terminal(lines, "run-free.png")


def shot_expander():
    body = body_lines("api_expander.txt")
    lines = [('$ python youtube_suggest_api_codes/keyword_expander.py "python" --depth 2 --language en',
              GREEN, True), ("", FG, False)]
    for l in body[:-1]:
        lines.append((clip(l), AMBER if "depth" in l else FG, False, CJK))
    lines += [("", FG, False), (clip(body[-1]), CYAN, True, CJK)]
    terminal(lines, "run-expander.png")


def shot_error():
    body = body_lines("api_error.txt")
    lines = [('$ export CHOCODATA_API_KEY="wrong_key"', GREEN, True),
             ('$ python youtube_suggest_api_codes/suggest.py "python"', GREEN, True), ("", FG, False)]
    for l in body[:4]:
        lines.append((clip(l), RED, True))
    lines += [("", FG, False),
              ("# no traceback, no silent empty list: every documented error", DIM, False),
              ("# maps to a message that tells you what to do next.", DIM, False)]
    terminal(lines, "run-error.png")


if __name__ == "__main__":
    shot_suggest()
    shot_free()
    shot_expander()
    shot_error()
