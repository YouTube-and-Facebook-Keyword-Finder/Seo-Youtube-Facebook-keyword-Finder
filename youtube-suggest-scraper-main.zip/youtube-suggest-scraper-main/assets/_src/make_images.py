"""Generate the repo's hero + evidence graphics with Pillow.

Every value rendered here is REAL and is read from a committed sample:

  * the JSON card comes from youtube_suggest_api_data/suggest.json
  * the retrieved-data table comes from row_count_survey.json (language=en)
  * the locales panel comes from suggest_locales.json (one seed, six locales)
  * the drift panel comes from drift_bare.json (one bare seed, six calls, 16s)

The multilingual panels are rendered with Yu Gothic so non-Latin suggestions
(Japanese) draw correctly rather than as boxes.
"""
import json
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFont

OUT = os.path.join(os.path.dirname(__file__), "..")
DATA = os.path.join(OUT, "..", "youtube_suggest_api_data")
F = "C:/Windows/Fonts/"

BOLD, SEMI, REG, MONO = "segoeuib.ttf", "seguisb.ttf", "segoeui.ttf", "consola.ttf"
CJK = "YuGothM.ttc"  # covers Latin + Japanese
INK, MUTE, DIM = (245, 243, 240), (169, 162, 154), (111, 106, 100)
ACC, ACC2 = (255, 143, 90), (255, 196, 138)
LAT_EXT = 0x0250  # keep Latin + Latin-1/extended; JP kana/kanji handled explicitly


def load(name):
    return json.load(open(os.path.join(DATA, name), encoding="utf-8"))


def font(name, size):
    for cand in (name, "segoeui.ttf"):
        try:
            return ImageFont.truetype(F + cand, size)
        except OSError:
            continue
    return ImageFont.load_default()


def renderable(ch):
    o = ord(ch)
    return o < LAT_EXT or 0x3000 <= o <= 0x30FF or 0x4E00 <= o <= 0x9FFF or ch in "’·"


def first_renderable(terms, seed, n=3):
    """Pick the first n suggestions that draw in the CJK+Latin font, dropping the
    seed echo and scripts the font cannot show (Korean/Thai/Hebrew) for legibility."""
    out = []
    for t in terms:
        if t == seed:
            continue
        if all(renderable(c) for c in t):
            out.append(t)
        if len(out) == n:
            break
    return out


def vgrad(w, h, top, bot):
    img = Image.new("RGB", (1, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / max(1, h - 1)
        d.point((0, y), tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3)))
    return img.resize((w, h))


def glow(img, cx, cy, rx, ry, color, strength):
    layer = Image.new("RGB", img.size, (0, 0, 0))
    d = ImageDraw.Draw(layer)
    steps = 44
    for i in range(steps, 0, -1):
        t = i / steps
        a = int(strength * (1 - t) ** 2.2)
        d.ellipse([cx - rx * t, cy - ry * t, cx + rx * t, cy + ry * t],
                  fill=tuple(int(c * a / 255) for c in color))
    return Image.fromarray(
        np.clip(np.asarray(img, dtype=int) + np.asarray(layer, dtype=int), 0, 255).astype("uint8"))


def pill(d, x, y, text, f, hot=False):
    w = d.textlength(text, font=f)
    d.rounded_rectangle([x, y, x + w + 28, y + 30], radius=15,
                        fill=(28, 20, 17) if hot else (25, 26, 30),
                        outline=(120, 66, 44) if hot else (52, 54, 60))
    d.text((x + 14, y + 6), text, font=f, fill=ACC2 if hot else (221, 214, 207))
    return w + 37


def hero():
    W, H = 1280, 540
    img = vgrad(W, H, (15, 17, 21), (26, 18, 16))
    img = glow(img, 1000, 100, 520, 300, (255, 143, 90), 46)
    img = glow(img, 150, 470, 420, 260, (120, 84, 60), 40)
    d = ImageDraw.Draw(img)
    for x in range(0, W, 64):
        d.line([(x, 0), (x, H)], fill=(24, 26, 31))
    for y in range(0, H, 64):
        d.line([(0, y), (W, y)], fill=(24, 26, 31))

    d.ellipse([64, 60, 75, 71], fill=ACC)
    d.text((88, 57), "C H O C O D A T A", font=font(SEMI, 15), fill=(185, 178, 170))

    d.text((64, 104), "YouTube Suggest", font=font(BOLD, 62), fill=INK)
    d.text((64, 174), "Scraper", font=font(BOLD, 62), fill=ACC)

    d.text((64, 276), "Extract YouTube's own autocomplete suggestions, the search", font=font(REG, 22), fill=MUTE)
    d.text((64, 308), "terms people actually type, in any language you ask for.", font=font(REG, 22), fill=MUTE)

    els = [("keyword suggestions", 1), ("autocomplete terms", 1), ("any language", 1),
           ("seed expansion", 0), ("CSV export", 0), ("keyword research", 0)]
    f = font(REG, 15)
    x, y = 64, 372
    for t, hot in els:
        w = d.textlength(t, font=f) + 37
        if x + w > 730:
            x, y = 64, y + 39
        x += pill(d, x, y, t, f, hot=bool(hot))

    data = load("suggest.json")
    cx, cy, cw = 828, 150, 388
    d.rounded_rectangle([cx, cy, cx + cw, cy + 300], radius=14, fill=(11, 13, 17), outline=(45, 47, 53))
    d.rounded_rectangle([cx, cy, cx + cw, cy + 38], radius=14, fill=(21, 23, 28))
    d.rectangle([cx, cy + 24, cx + cw, cy + 38], fill=(21, 23, 28))
    for i, c in enumerate([(255, 95, 87), (254, 188, 46), (40, 200, 64)]):
        d.ellipse([cx + 14 + i * 18, cy + 14, cx + 24 + i * 18, cy + 24], fill=c)
    d.line([(cx, cy + 38), (cx + cw, cy + 38)], fill=(38, 40, 46))

    shown = data["related_searches"][:3]
    rest = len(data["related_searches"]) - len(shown)
    rows = [("{", None, None), ('  "query"', f'"{data["query"]}"', "s"),
            ('  "related_searches"', "[", None)]
    for s in shown:
        rows.append((f'    "{s}",', None, "v"))
    rows += [(f"    ... {rest} more", None, None), ("  ],", None, None),
             ('  "related_count"', str(data["related_count"]), "n"), ("}", None, None)]
    fm = font(MONO, 13)
    yy = cy + 54
    for k, v, kind in rows:
        if kind == "v":
            d.text((cx + 18, yy), k, font=fm, fill=(154, 230, 160))
        elif v is None:
            d.text((cx + 18, yy), k, font=fm, fill=DIM)
        else:
            d.text((cx + 18, yy), k, font=fm, fill=(127, 178, 255))
            kw = d.textlength(k, font=fm)
            d.text((cx + 18 + kw, yy), ": ", font=fm, fill=DIM)
            d.text((cx + 18 + kw + d.textlength(": ", font=fm), yy), v, font=fm,
                   fill=(154, 230, 160) if kind == "s" else ACC2)
        yy += 24

    d.text((828, 500), "one endpoint  ·  real JSON  ·  any locale", font=font(REG, 14), fill=DIM)
    img.save(os.path.join(OUT, "hero.png"))
    print("wrote assets/hero.png", img.size)


def retrieved():
    """What you get back, as a table: seed keyword -> its suggestions (language=en)."""
    s = load("row_count_survey.json")
    picks = ["python", "how to make espresso", "lofi hip hop", "minecraft",
             "guitar lesson", "yoga for beginners", "excel tutorial"]
    rows = []
    for p in picks:
        for smp in s["samples"]:
            if smp["query"] == p:
                rows.append(smp)
                break
    assert len(rows) == len(picks), "every seed must exist in the survey"

    cols = [("seed", 170), ("suggestions returned by YouTube (language=en)", 790), ("rows", 60)]
    W = sum(c[1] for c in cols) + 40
    rh, hh = 32, 34
    Hh = 52 + hh + rh * len(rows)
    img = Image.new("RGB", (W, Hh), (255, 255, 255))
    d = ImageDraw.Draw(img)
    UI, UIB, M = font(REG, 14), font(SEMI, 14), font(MONO, 13)
    d.text((20, 14), "youtube_suggest", font=font(SEMI, 15), fill=(30, 30, 30))
    x0, y0 = 20, 46
    d.rectangle([x0, y0, W - 20, y0 + hh], fill=(238, 238, 238))
    x = x0
    for name, w in cols:
        d.text((x + 9, y0 + 9), name, font=UIB, fill=(20, 20, 20))
        x += w
    y = y0 + hh
    for i, r in enumerate(rows):
        if i % 2:
            d.rectangle([x0, y, W - 20, y + rh], fill=(250, 250, 250))
        joined = ", ".join(r["related_searches"])
        if len(joined) > 94:
            joined = joined[:93] + "…"
        vals = [r["query"], joined, str(r["rows"])]
        x = x0
        for (name, w), v in zip(cols, vals):
            d.text((x + 9, y + 8), v, font=M if name == "seed" or name == "rows" else UI, fill=(60, 60, 60))
            x += w
        d.line([(x0, y), (W - 20, y)], fill=(226, 226, 226))
        y += rh
    d.line([(x0, y), (W - 20, y)], fill=(226, 226, 226))
    for i in range(len(cols) + 1):
        xx = x0 + sum(c[1] for c in cols[:i])
        d.line([(xx, y0), (xx, y)], fill=(226, 226, 226))
    img.save(os.path.join(OUT, "retrieved-data.png"))
    print("wrote assets/retrieved-data.png", img.size)


def locales():
    """The same seed, six locales. Pass language and the whole list changes."""
    m = load("suggest_locales.json")
    order = [("en_us", "language=en"), ("es_es", "language=es"), ("de_de", "language=de"),
             ("ja_jp", "language=ja"), ("fr_fr", "language=fr")]
    seed = "python"
    W, H = 1280, 430
    img = vgrad(W, H, (15, 17, 21), (22, 17, 15))
    d = ImageDraw.Draw(img)
    d.text((64, 40), "The same seed, five languages. Pass `language` and the whole list changes.",
           font=font(BOLD, 25), fill=INK)
    d.text((64, 78), f"Seed {seed!r}, captured 2026-07-20. Full matrix in "
                     "youtube_suggest_api_data/suggest_locales.json.", font=font(REG, 14), fill=DIM)

    cardw = (W - 64 * 2 - 4 * 16) // 5
    fm = font(CJK, 13)
    for i, (key, label) in enumerate(order):
        x = 64 + i * (cardw + 16)
        d.rounded_rectangle([x, 120, x + cardw, 400], radius=11, fill=(18, 20, 25), outline=(48, 50, 57))
        d.text((x + 14, 134), label, font=font(SEMI, 13), fill=(150, 190, 240))
        terms = m[key]["related_searches"][:6]
        yy = 168
        for t in terms:
            s = t if len(t) <= 22 else t[:21] + "…"
            d.text((x + 14, yy), s, font=fm, fill=(200, 194, 188))
            yy += 34
    img.save(os.path.join(OUT, "locales.png"))
    print("wrote assets/locales.png", img.size)


def drift():
    """The same bare seed, six calls, 16 seconds: with no language param the
    locale is not pinned and drifts between calls."""
    dd = load("drift_bare.json")
    seed = dd["seed"]
    calls = dd["calls"]
    W = 1280
    rowh = 46
    H = 150 + rowh * len(calls) + 30
    img = vgrad(W, H, (15, 17, 21), (22, 16, 15))
    d = ImageDraw.Draw(img)
    d.text((64, 40), "No `language` param? The locale is not pinned, so it drifts.",
           font=font(BOLD, 25), fill=INK)
    d.text((64, 78), f"Seed {seed!r}, no language/country, six calls in 16 seconds on 2026-07-20. "
                     "Each returned a different language.", font=font(REG, 14), fill=DIM)

    fm = font(CJK, 15)
    y = 132
    for c in calls:
        terms = first_renderable(c["related_searches"], seed, n=3)
        d.rounded_rectangle([64, y, 1216, y + rowh - 8], radius=9, fill=(18, 20, 25), outline=(48, 50, 57))
        d.text((80, y + 9), f"call {c['call']}", font=font(SEMI, 13), fill=ACC2)
        d.text((160, y + 9), c["ts"], font=font(MONO, 13), fill=DIM)
        d.text((270, y + 9), "  ·  ".join(terms), font=fm, fill=(205, 199, 193))
        y += rowh
    img.save(os.path.join(OUT, "drift.png"))
    print("wrote assets/drift.png", img.size)


if __name__ == "__main__":
    hero()
    retrieved()
    locales()
    drift()
