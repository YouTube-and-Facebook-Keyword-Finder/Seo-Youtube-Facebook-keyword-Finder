"""Free YouTube suggest scraper.

YouTube exposes no "related searches" block in its search HTML. The source every
keyword tool uses is Google's autocomplete ("suggest") endpoint scoped to the
YouTube dataset (`ds=yt`). The `client=firefox` variant returns clean JSON with
no key and no JSONP wrapper:

    ["<query>", ["suggestion 1", "suggestion 2", ...], [], {...}]

A plain server-side GET works. `hl` (language) and `gl` (country) pin the locale;
leave them off and Google localises to the caller's IP.

Detection order matters: we parse first, and only call something a block when the
JSON has no suggestions AND a challenge marker is present.

Usage:
    python free_scraper/youtube_suggest_free_scraper.py "python" en
"""
import json
import sys
import urllib.parse

import requests

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Accept": "*/*", "Accept-Language": "en-US,en;q=0.9"}


def build_url(query: str, language: str | None = None, country: str | None = None) -> str:
    parts = ["client=firefox", "ds=yt", "q=" + urllib.parse.quote(query)]
    if language:
        parts.append("hl=" + urllib.parse.quote(language))
    if country:
        parts.append("gl=" + urllib.parse.quote(country))
    return "https://suggestqueries.google.com/complete/search?" + "&".join(parts)


def parse(body: str):
    """Return the suggestion list, or None if the JSON did not parse."""
    try:
        arr = json.loads(body)
    except json.JSONDecodeError:
        return None
    if not isinstance(arr, list) or len(arr) < 2 or not isinstance(arr[1], list):
        return None
    return [s if isinstance(s, str) else (s[0] if isinstance(s, list) and s else "")
            for s in arr[1]]


def scrape(query: str, language: str | None = None, country: str | None = None):
    url = build_url(query, language, country)
    r = requests.get(url, headers=HEADERS, timeout=30)
    suggestions = parse(r.text)

    if suggestions:  # real data, whatever else is in the body
        return {"ok": True, "status": r.status_code, "bytes": len(r.content),
                "query": query, "related_searches": suggestions}

    lower = r.text.lower()
    blocked = "/sorry/" in r.url or "unusual traffic" in lower or "captcha" in lower
    return {"ok": False, "status": r.status_code, "bytes": len(r.content),
            "query": query, "parsed": suggestions is not None, "blocked": blocked}


def main() -> None:
    query = sys.argv[1] if len(sys.argv) > 1 else "python"
    language = sys.argv[2] if len(sys.argv) > 2 else None
    country = sys.argv[3] if len(sys.argv) > 3 else None
    res = scrape(query, language, country)

    print(f"GET {build_url(query, language, country)}")
    print(f"HTTP {res['status']}  {res['bytes']:,} bytes")
    if res["ok"]:
        print(f"\n{len(res['related_searches'])} suggestions for {query!r}:")
        for s in res["related_searches"]:
            print(f"  {s}")
        return

    print(f"parsed JSON: {res['parsed']}   challenge marker: {res['blocked']}")
    print("\nNO DATA: the suggest endpoint returned no suggestions.")
    sys.exit(1)


if __name__ == "__main__":
    main()
